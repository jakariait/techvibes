import React from 'react';

const ProfileCoverPhoto = () => {
  return (
    <div>
      ss
    </div>
  );
};

export default ProfileCoverPhoto;