import React from 'react';

const Bio = ({profile}) => {
  return (
    <div>
      bio
    </div>
  );
};

export default Bio;