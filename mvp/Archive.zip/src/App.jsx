import FromFigma from "./components/FromFigma.jsx";


function App() {
	return (
		<>
			<FromFigma/>
		</>
	);
}

export default App;
